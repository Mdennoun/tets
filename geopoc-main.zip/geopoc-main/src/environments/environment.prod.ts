export const environment = {
  production: true,
  mapbox: {
    accessToken: 'pk.eyJ1IjoibWRlbm5vdW4iLCJhIjoiY2wyc3RmZWp3MDIzNzNjbHJwdTVkbmV3diJ9.jWOEp5-vmM3XrhYhd6UUng',
  },
};
