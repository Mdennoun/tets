import { async, TestBed, waitForAsync } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { BanService } from './ban-autocomplete/ban-services'
import { HttpClientTestingModule, HttpTestingController }
  from '@angular/common/http/testing';

import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

import { BanApiData } from './ban-autocomplete/ban-api-interface';

import { Properties, Feature, Geometry } from './ban-autocomplete/ban-data';
import { empty } from 'rxjs';
import { BanAutocompleteComponent } from './ban-autocomplete/ban-autocomplete.component';



describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'geoApp'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('geoApp');
  });

});
