import { Component, NgModule, OnInit } from '@angular/core';
import { BanService } from './ban-services';
import { BanApiData } from './ban-api-interface';
import { Feature, Properties } from './ban-data';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as L from 'leaflet';
import { Observable, Subscriber } from 'rxjs';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-ban-autocomplete',
  templateUrl: './ban-autocomplete.component.html',
  styleUrls: ['./ban-autocomplete.component.css'],
  providers: [BanService]
})

export class BanAutocompleteComponent implements OnInit {
  root!: BanApiData;
  banFeaturesArray: Feature[] = []
  searchVal: string = "";
  startsearchVal: number = 0;
  banRequestNumber: number = 0;
  map: any;
  searchText: string = "";
  isShown: boolean = false;


  loading: boolean = false;
  errorMessage?: string;
  eventInput: any;

  constructor(private banService: BanService) { }

  ngOnInit(): void {
  }

  select(adr: string, x: any, y: any) {
    console.log(adr);
    this.eventInput.target.value = adr;
    this.loadMap(x, y);
    this.banFeaturesArray = [];

  }


  public startFrom(event: any) {
    this.startsearchVal = event.target.value
  }

  public GetPropreties(event: any) {
    this.eventInput = event;
    this.banFeaturesArray = [];

    this.errorMessage = "";
    var test = event.target.value.length;
    if (test >= this.startsearchVal) {
      this.loading = true;
      this.banService.GetPropreties(event.target.value)
        .subscribe((data: any) => {
          console.log(data.features.properties)
          const features = data.features
          features.forEach((f: Feature) => {
            this.banFeaturesArray.push(f)
            console.log(f)
          });
          this.banRequestNumber += 1;
          this.loading = false;

        });
    }
    console.log(this.banRequestNumber)

  }

  public setSearchText(event: any) {
    this.searchText = event.target.value;
  }
  public getBanDataOnClick(event: any) {
    this.eventInput = event;
    this.banFeaturesArray = [];
    this.errorMessage = "";
    this.loading = true;
    this.banService.GetPropreties(this.searchText)
      .subscribe((data: any) => {
        console.log(data.features.properties)
        const features = data.features
        features.forEach((f: Feature) => {
          this.banFeaturesArray.push(f)
          console.log(f)
        });
        this.banRequestNumber += 1;
        this.loading = false;

      });

  }
  public toggleShow(): void {
    this.isShown = !this.isShown;
  }
  public getCurrentRequestNB(): number {
    return this.banRequestNumber;
  }


  private getCurrentPosition(): any {
    return new Observable((observer: Subscriber<any>) => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position: any) => {
          observer.next({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
          observer.complete();
        });
      } else {
        observer.error();
      }
    });
  }
  private SetCursorOnSelectedPosition(x: any, y: any): any {
    return new Observable((observer: Subscriber<any>) => {
      if (navigator.geolocation) {

        observer.next({
          latitude: y,
          longitude: x,
        });
        observer.complete();

      } else {
        observer.error();
      }
    });
  }


  private loadMap(x: any, y: any): void {
    var att = 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>';
    var mapboxUrl = 'https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWRlbm5vdW4iLCJhIjoiY2wyc3RmZWp3MDIzNzNjbHJwdTVkbmV3diJ9.jWOEp5-vmM3XrhYhd6UUng';
    var grayscale = L.tileLayer(mapboxUrl, { id: 'mapbox/outdoors-v11', tileSize: 512, zoomOffset: -1, attribution: att });
    var streets = L.tileLayer(mapboxUrl, { id: 'mapbox/streets-v11', tileSize: 512, zoomOffset: -1, attribution: att });
    var satellite = L.tileLayer(mapboxUrl, { id: 'mapbox/satellite-v9', tileSize: 512, zoomOffset: -1, attribution: att });
    var satelliteStreet = L.tileLayer(mapboxUrl, { id: 'mapbox/satellite-streets-v11', tileSize: 512, zoomOffset: -1, attribution: att });
    var darkMap = L.tileLayer(mapboxUrl, { id: 'mapbox/dark-v10', tileSize: 512, zoomOffset: -1, attribution: att });
    var navigationDay = L.tileLayer(mapboxUrl, { id: 'mapbox/navigation-day-v1', tileSize: 512, zoomOffset: -1, attribution: att });
    var navigationNight = L.tileLayer(mapboxUrl, { id: 'mapbox/navigation-night-v1', tileSize: 512, zoomOffset: -1, attribution: att })

    var baseLayers = {
      'Grayscale': grayscale,
      'Streets': streets,
      'Satellite': satellite,
      'Satellite Streets': satelliteStreet,
      'dark': darkMap,
      'Navigation day': navigationDay,
      'Navigation night': navigationNight
    };


    this.map = L.map('map', {
      center: [39.73, -104.99],
      zoom: 10,
      layers: [grayscale, streets, satellite, satelliteStreet, darkMap, navigationDay, navigationNight]
    });

    var layerControl = L.control.layers(baseLayers).addTo(this.map);

    this.SetCursorOnSelectedPosition(x, y)
      .subscribe((position: any) => {
        this.map.flyTo([position.latitude, position.longitude], 13);

        const icon = L.icon({
          iconUrl: 'assets/images/marker-icon.png',
          shadowUrl: 'assets/images/marker-shadow.png',
          popupAnchor: [13, 0],
        });

        const marker = L.marker([position.latitude, position.longitude], { icon }).bindPopup('Angular Leaflet');
        marker.addTo(this.map);
      });
  }



  private getRandomInt(max: number) {
    return Math.floor(Math.random() * max);
  }


}
