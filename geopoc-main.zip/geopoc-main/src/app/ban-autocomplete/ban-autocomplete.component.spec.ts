import { HttpClient, HttpClientModule } from '@angular/common/http';
import {
  HttpClientTestingModule,
  HttpTestingController,
} from '@angular/common/http/testing';
import { Injectable, NgModule } from '@angular/core';
import { Observable } from 'rxjs';

import { MockBuilder, MockRender } from 'ng-mocks';
import { BanApiData } from './ban-api-interface';
import { BanService } from './ban-services';



// A module providing the service and http client.
@NgModule({
  imports: [HttpClientModule],
  providers: [BanService],
})
class TargetModule { }

describe('TestHttpRequest', () => {
  // Because we want to test the service, we pass it as the first
  // parameter of MockBuilder. To correctly satisfy its
  // initialization, we need to pass its module as the second
  // parameter. And, the last but not the least, we need to replace
  // HttpClientModule with HttpClientTestingModule.
  beforeEach(() => {
    return MockBuilder(BanService, TargetModule).replace(
      HttpClientModule,
      HttpClientTestingModule,
    );
  });

  it('Get Adresse request test. Expect Ban Service response', () => {
    const fixture = MockRender('');
    // Let's extract the service and http controller for testing.
    const service: BanService =
      fixture.debugElement.injector.get(BanService);
    const httpMock: HttpTestingController =
      fixture.debugElement.injector.get(HttpTestingController);

    // A simple subscription to check what the service returns.
    let actual: any;
    service.GetPropreties('search').subscribe(value => (actual = value));

    // Simulating a request.
    const req = httpMock.expectOne('https://api-adresse.data.gouv.fr/search/?q=search&autocomplete=1');
    expect(req.request.method).toEqual('GET');
    req.flush(mockData);
    httpMock.verify();

    // Asserting the result.
    expect(actual).toEqual(mockData);
  });
});
export const mockData: BanApiData = {
  type: 'FeatureCollection',
  version: 'draft',
  features: [
    {
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: [
          2.290084,
          49.897443
        ]
      },
      properties: {
        label: '8 Boulevard du Port 80000 Amiens',
        score: 0.49245200956937796,
        housenumber: '8',
        id: '80021_6590_00008',
        name: '8 Boulevard du Port',
        postcode: '80000',
        citycode: '80021',
        x: 648952.58,
        y: 6977867.25,
        city: 'Amiens',
        context: '80, Somme, Hauts-de-France',
        type: 'housenumber',
        importance: 0.68013,
        street: 'Boulevard du Port'
      }
    },
  ],
  attribution: 'BAN',
  licence: 'ETALAB-2.0',
  query: '8 bd du port',
  limit: 1
};
