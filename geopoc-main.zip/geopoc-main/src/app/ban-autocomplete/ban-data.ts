export interface Geometry {
    type: string;
    coordinates: number[];
}

export interface Properties {
    label: string;
    score: number;
    housenumber: string;
    id: string;
    type: string;
    name: string;
    postcode: string;
    citycode: string;
    x: number;
    y: number;
    city: string;
    context: string;
    importance: number;
    street: string;
}

export interface Feature {
    type: string;
    geometry: Geometry;
    properties: Properties;
}
