import { Injectable } from '@angular/core';

import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, shareReplay } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

import { BanApiData } from './ban-api-interface';

@Injectable()
export class BanService {

    baseURL: string = "https://api-adresse.data.gouv.fr/search/?q=";
    static GetPropreties: any;


    constructor(private http: HttpClient) {

    }

    GetPropreties(search: string): Observable<BanApiData> {
        return this.http.get<BanApiData>(this.baseURL + search + "&autocomplete=1").pipe(shareReplay(1))
    }

}