import { Feature } from "./ban-data";

export interface BanApiData {
    type: string;
    version: string;
    features: Feature[];
    attribution: string;
    licence: string;
    query: string;
    limit: number;
}
