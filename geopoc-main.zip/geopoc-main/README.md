# Geopoc

Afin de lancer le projet il faut installer :

- node version v14 minimum 
- Angular version 13
- npm 


**Installation :**

Apres avoir installé les outils il faut:
 
- installer les packages:

    `npm i` 

- Demarrer le serveur : 

    `npm start`


- Lancement des tests : 

    `ng test`
